//pathBase='http://localhost/app/app20/platforms/android/assets/www/site/';
pathBase='http://hiresto.com/sg/site/app/';

var sg = {

  init: function(){
      alert('Starting superguest');
      sg.redefineTargetLink();
  },

  /* Functions for module */

  moduleConstructor: function(){
    alert('module moduleConstructor');
    $(function(){
      var src=pathBase+'app/system/module/moduleView.html';
      $('<iframe id="targetURL" src="'+src+'" class="target-URL hidden"/>').appendTo('body');
      $('.target-URL').animate({left: 1000}, 300, function() {});
    });
  },

  moduleOpen: function(link){
    $('#wrapper-aside').animate({left: "-=80%"}, 300, function() {
      $('#targetURL').removeClass("hidden");
      $('.target-URL').animate({left: 0}, 300, function() {});
    });
  },

  moduleClose: function(){
    $('.target-URL').animate({left: 1000}, 300, function() {
      $('#targetURL').addClass("hidden");
    });
  },

  /* Functions for modal */
  modalOpen: function(link){
    if($('#modal-content').load(link)){
      $('#modal-wrapper').removeClass("hidden");
    }       
  },

  modalClose: function(){
    $('#modal-content').html('');
    $('#modal-wrapper').addClass("hidden");
  },

  redefineTargetLink: function(){
    sg.moduleConstructor();
    
    $('a').on('click', function(event) {
      event.preventDefault();
      var link = $(this).attr('href'); 
      var target = $(this).attr('target');

      switch(target) {
        case 'modal':
          sg.modalOpen(link);
          break;
        case 'module':
          sg.moduleOpen(link);
          break;
        default:
          window.open(link);
      }

    });
  },

  mainMenuOpen: function(){
    $('#wrapper-aside').animate({left: "+=80%"}, 300, function() {});
  },

  mainMenuClose: function(){
    $('#wrapper-aside').animate({left: "-=80%"}, 300, function() {});    
  },

};

$(document).ready(function(){
 
  $('.btn-icon-menu').on('click', function () {
    sg.mainMenuOpen();
  });
  
  $('.wrapper-content').on('click', function () {
    sg.mainMenuClose();
  });

  $('#modal-header-close').click(function(){
    sg.modalClose();
  });
  
  sg.init();
});
